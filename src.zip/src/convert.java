/**
 * Created by fitore on 12.03.18.
 */
public class convert {
    public static String convert(double x, String valuta1, String valuta2){
        double result=0;
        String message="";

        String a = valuta1.trim().toUpperCase();
        String b = valuta2.trim().toUpperCase();

        if(a ==("EURO") && b ==("DOLLAR")){
            result=x*0.84;
        }else  if( a ==("DOLLAR")&& b ==("EURO")){
            result=x*1.25;
        }else if (a ==("EURO")&& b ==("YEN")){
            result = 123*x;
        }else if(a == ("DOLLAR") && b == ("YEN")){
            result = 102*x;
        }else{
            return "Nuk mund te konvertohet kjo valute ";
        }
        return result + " " + b;

    }
    public static void main(String [] args){
        System.out.println(convert.convert(2,"DOLLAR","YEN"));
    }
}
