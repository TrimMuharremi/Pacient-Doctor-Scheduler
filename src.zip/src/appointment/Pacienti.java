package appointment;

import java.util.Date;

/**
 * Created by fitore on 17.04.18.
 */
public class Pacienti {
    private int pacientID;
    private String emri;
    private String mbiemri;
    private String adresa;
    private String informata;
    private Date datelindja;



    public Pacienti(int pacientID, String emri, String mbiemri, String adresa, String informata){
        this.pacientID = pacientID;
        this.emri = emri;
        this.mbiemri = mbiemri;

        this.adresa = adresa;
        this.informata = informata;
        this.datelindja = datelindja;
    }


    public int getPacientId(){
        return pacientID;
    }

    public void setPacientID(int newId){
        pacientID = newId;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }
    public String getEmri() {
        return emri;
    }

    public void setEmri(String emri) {
        this.emri = emri;
    }

    public String getMbiemri() {
        return mbiemri;
    }

    public void setMbiemri(String mbiemri) {
        this.mbiemri = mbiemri;
    }
    public String getInformata() {
        return informata;
    }

    public void setInformata(String informata) {
        this.informata = informata;
    }

    public Date getDatelindja() {
        return datelindja;
    }

    public void setDatelindja(Date datelindja) {
        this.datelindja = datelindja;
    }

}

