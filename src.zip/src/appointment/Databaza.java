package appointment;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by fitore on 16.05.18.
 */
public class Databaza {

    public Databaza(){
        shtoMjeket();
    }

    private static ArrayList<Pacienti> pacienti = new ArrayList<Pacienti>();
    private static Mjeku [] mjeku = new Mjeku[5];
    private static Termini [] termini = new Termini[20];

    private void shtoMjeket(){
        mjeku[0] = new Mjeku(1, "Afrim", "Blyta");
        mjeku[1] = new Mjeku(2, "Tefik", "Heta");
        mjeku[2] = new Mjeku(3, "Agim", "Bytyqi");
        mjeku[3] = new Mjeku(4, "Arif", "Meha");
        mjeku[4] = new Mjeku(5, "Nehat", "Gashi");
    }

    public void shtoPacient(String emri, String mbiemri, String adresa, String informata){

        int i = pacienti.size();
            pacienti.add(new Pacienti(i + 1, emri, mbiemri, adresa, informata));
    }

    public ArrayList<Pacienti> getPacientet(){
        return pacienti;
    }

    public int nextPatientId(){
        return pacienti.size();
    }

    public void shtoTermin(Date date, Mjeku mjeku, Pacienti pacienti) {

        int i = termini.length;
        termini[i] = new Termini(date, mjeku, pacienti);
    }
}
