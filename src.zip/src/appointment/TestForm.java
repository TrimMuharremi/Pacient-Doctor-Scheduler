package appointment;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fitore on 16.05.18.
 */
public class TestForm {

    private JPanel panelMain;
    private JPanel panelLeft;
    private JPanel panelRight;
    private JTextField textEmri;
    private JLabel labelEmri;
    private JTextField textmbiemri;
    private JLabel labelMbiemri;
    private JLabel textData;
    private JTextField textFieldData;
    private JLabel labelAdresa;
    private JTextField textFieldAdresa;
    private JLabel labelInfo;
    private JButton buttonRuaj;
    private JTextArea textAreaInfo;
    private JTextField textField2;
    private JLabel labelMjeku;
    private JLabel labelData;
    private JComboBox comboBoxMjeku;
    private JLabel IdLabel;;
    private JTextField textFieldPacientiId;
    private JButton ruajTermininButton;
    private JButton pacientetERegjistruarButton;
    private JButton terminetButton;

    private Databaza databaza = new Databaza();

    public TestForm() {

        IdLabel.setText(databaza.nextPatientId()+ 1 + "");
        buttonRuaj.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                databaza.shtoPacient(textEmri.getText(),textmbiemri.getText(),textFieldAdresa.getText(),textAreaInfo.getText());
                textEmri.setText("");
                textmbiemri.setText("");
                textFieldAdresa.setText("");
                textAreaInfo.setText("");
                IdLabel.setText(databaza.nextPatientId()+ 1 + "");
            }
        });
        pacientetERegjistruarButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        pacientetERegjistruarButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                new Pacientet();
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Terminet");
        frame.setContentPane(new TestForm().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(500,400);
        frame.setVisible(true);
    }
}
