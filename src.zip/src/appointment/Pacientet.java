package appointment;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Created by fitore on 16.05.18.
 */
public class Pacientet extends JFrame{

    private JPanel panelmain;
    private JTextArea textArea = new JTextArea();
    Databaza db = new Databaza();
    ArrayList<Pacienti> myArray = db.getPacientet();


    //konstruktori
    Pacientet(){

        JFrame frame = new JFrame("Pacientet e Regjistruar");
        frame.setContentPane(new Pacientet().panelmain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(500,400);
        frame.setVisible(true);
        for (int i=0; i<myArray.size(); i++)
        {
            textArea.append(i + " " + myArray.get(i)+"\n");
        }

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pacientet e Regjistruar");
        frame.setContentPane(new Pacientet().panelmain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
      frame.setSize(500,400);
        frame.setVisible(true);
    }
}
