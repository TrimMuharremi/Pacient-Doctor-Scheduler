package appointment;

/**
 * Created by fitore on 17.04.18.
 */
public class Mjeku {

    private int ID;
    private String emri;
    private String mbiemri;
    public Mjeku(int ID, String emri, String mbiemri){
        this.ID = ID;
        this.emri = emri;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getEmri() {
        return emri;
    }

    public void setEmri(String emri) {
        this.emri = emri;
    }

    public String getMbiemri() {
        return mbiemri;
    }

    public void setMbiemri(String emri) {
        this.mbiemri = mbiemri;
    }



}
