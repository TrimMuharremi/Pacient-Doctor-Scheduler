package appointment;

import java.util.Date;

/**
 * Created by fitore on 17.04.18.
 */
public class Termini {
    private Date data;
    private Mjeku mjeku;
    private Pacienti pacienti;

    public Termini(Date data, Mjeku mjeku, Pacienti pacienti){
        this.data=data;
        this.mjeku=mjeku;
        this.pacienti=pacienti;
    }
    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Mjeku getMjeku() {
        return mjeku;
    }

    public void setMjeku(Mjeku mjeku) {
        this.mjeku = mjeku;
    }

    public Pacienti getPacienti() {
        return pacienti;
    }

    public void setPacienti(Pacienti pacienti) {
        this.pacienti = pacienti;
    }

}
